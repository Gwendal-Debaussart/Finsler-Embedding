import itertools
import torch
import numpy as np
import pandas as pd

from finsler_embedding.eval_operators import main as main_eval
from finsler_embedding.eval_operators import EvalOperators


def main():
    beta_list = torch.tensor([0.1, 0.3, 0.5, 0.7, 0.9])
    N_list = [1000, 2000, 4000]
    df_list = []
    for beta, N, seed in itertools.product(beta_list, N_list, range(3)):
            print(f"Running beta={beta.item()}, N={N}, seed={seed}")
            torch.manual_seed(seed)
            np.random.seed(seed)
            config: EvalOperators = EvalOperators(
                dataset="swiss_roll",
                n=N,
                m=2,
                beta=beta.item(),
                graph_type="radius",
                embedding_type="isomap",
                k=15,
                eps_scale=1.0,
                eps0=1.0,
                cut=0.0,
                radius=5.0,
            )
            df = main_eval(config)
            df["seed"] = seed
            df_list.append(df)
            pd.concat(df_list, ignore_index=True).to_csv(
                "./results/eval_operators_swiss_roll.csv", index=False
            )

    df_tot = pd.concat(df_list, ignore_index=True)
    df_tot.to_csv("./results/eval_operators_swiss_roll.csv", index=False)


if __name__ == "__main__":
    main()
